// Independent raw-data audit: derive metrics from persisted effects/outbox,
// rather than trust the experiment driver's aggregate counters.
import {readFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
const out=resolve(process.argv[2]||'runs/main');
const raw=readFileSync(join(out,'raw.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const batches=JSON.parse(readFileSync(join(out,'batches.json'),'utf8'));
for(const b of batches){
 const r=new DatabaseSync(join(out,b.label,'receiver.db'),{readOnly:true}),s=new DatabaseSync(join(out,b.label,'sender.db'),{readOnly:true});
 let duplicate=0,missing=0,unknown=0,retries=0;
 for(const x of raw.filter(x=>x.label===b.label)){
  const n=r.prepare('SELECT count(*) n FROM effects WHERE id=?').get(x.id).n;
  const row=s.prepare('SELECT * FROM outbox WHERE id=?').get(x.id);
  assert.equal(n,x.effects);assert.equal(row.state,x.after);
  assert.equal(row.attempts,x.attempts,`request accounting: ${b.label}/${x.id}`);
  duplicate+=Math.max(n-1,0);missing+=n===0?1:0;unknown+=row.state!=='CONFIRMED'?1:0;retries+=row.attempts-1;
 }
 assert.equal(duplicate,b.duplicateEffects);assert.equal(missing,b.missing);assert.equal(unknown,b.unknownAfterQuery);assert.equal(retries,b.duplicateRequests);
 r.close();s.close();
}
console.log(`Audited ${batches.length} databases pairs and ${raw.length} raw task rows`);
