import {mkdirSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {openReceiver,sign} from './core.mjs';
const out=resolve(process.argv[2]||'runs/storage');
mkdirSync(out,{recursive:true});
if(existsSync(join(out,'storage.json')))throw Error('Refusing overwrite');
const results=[];
for(const group of ['B','C'])for(const ttl of [10,150]){
 const db=join(out,`${group}-${ttl}.db`),r=openReceiver(db,group,{ttl}),timeline=[];
 for(let t=0;t<200;t++){
  r.cleanup(t);r.receive(sign({id:`task-${t}`,payload:'61 ships',deadline:t+100}),t);
  timeline.push({t,...r.stats()});
 }
 const before=r.stats();r.cleanup(400);const after=r.stats();r.close();
 results.push({group,ttl,deadlineHorizon:100,peakDedup:Math.max(...timeline.map(x=>x.dedup)),before,after,timeline});
}
writeFileSync(join(out,'storage.json'),JSON.stringify(results,null,2));
console.log(results.map(({timeline,...r})=>r));
