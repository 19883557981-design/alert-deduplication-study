// Laboratory process adapter. Fault hooks suspend a real SQLite transaction
// so the parent can terminate the OS process, rather than throw an exception.
import {writeFileSync,existsSync} from 'node:fs';
import {openReceiver,openSender} from './core.mjs';
const a=JSON.parse(process.argv[2]);
function barrier(name){
 if(a.pause!==name)return;
 writeFileSync(a.marker,JSON.stringify({pid:process.pid,stage:name}));
 const start=Date.now();
 while(!existsSync(a.release)){
  if(Date.now()-start>15000)throw Error('barrier timed out');
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10);
 }
}
try{
 if(a.role==='receiver'){
  const r=openReceiver(a.db,a.group,{ttl:a.ttl});
  const result=a.action==='cleanup'?r.cleanup(a.now):r.receive(a.request,a.now,{
   locked:()=>barrier('locked'),beforeCommit:()=>barrier('beforeCommit'),afterCommit:()=>barrier('afterCommit')
  });
  r.close();process.stdout.write(JSON.stringify(result));
 }else{
  const s=openSender(a.db);
  if(a.action==='enqueue')s.enqueue(a.request,{afterAlert:()=>barrier('afterAlert')});
  else{
   const request=s.begin(a.request.id,a.now,a.group);
   if(request){
    // Parent is the fault-injecting transport. Its response file is a real
    // receiver's result; the sender never inspects the receiver database.
    writeFileSync(a.outgoing,JSON.stringify(request));
    const start=Date.now();
    while(!existsSync(a.incoming)){
     if(Date.now()-start>15000)throw Error('response timed out');
     Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10);
    }
    const {readFileSync}=await import('node:fs');
    const response=JSON.parse(readFileSync(a.incoming,'utf8'));
    barrier('beforeSave');s.finish(request.id,response,a.now);
   }
  }
  s.close();process.stdout.write(JSON.stringify({ok:true}));
 }
}catch(e){process.stderr.write(e.stack);process.exitCode=1;}
