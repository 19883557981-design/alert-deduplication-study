import {DatabaseSync} from 'node:sqlite';
import {createHash,createHmac} from 'node:crypto';
const KEY='public-laboratory-fixture-not-a-production-secret';
const digest=p=>createHash('sha256').update(p).digest('hex');
const token=r=>createHmac('sha256',KEY).update(JSON.stringify([r.id,r.payload,r.deadline])).digest('hex');
export const sign=r=>({...r,signature:token(r)});
function database(path){
 const db=new DatabaseSync(path);
 db.exec('PRAGMA busy_timeout=10000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;');
 return db;
}
function transaction(db,fn){
 db.exec('BEGIN IMMEDIATE');
 try{const result=fn();db.exec('COMMIT');return result;}
 catch(e){db.exec('ROLLBACK');throw e;}
}
export function openReceiver(path,group,{ttl=10}={}){
 if(!['A','B','C'].includes(group))throw Error('unknown group');
 const db=database(path);
 db.exec(`CREATE TABLE IF NOT EXISTS dedup(id TEXT PRIMARY KEY,hash TEXT,deadline REAL,retain_until REAL,effect_id INTEGER);
 CREATE TABLE IF NOT EXISTS effects(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT,payload TEXT,at REAL);
 CREATE TABLE IF NOT EXISTS meta(name TEXT PRIMARY KEY,value REAL);
 INSERT OR IGNORE INTO meta VALUES('clock',-1);`);
 function effectiveTime(now){
  if(!Number.isFinite(now))throw Error('invalid time');
  const old=db.prepare("SELECT value FROM meta WHERE name='clock'").get().value;
  const t=group==='C'?Math.max(old,now):now;
  db.prepare("UPDATE meta SET value=? WHERE name='clock'").run(t);return t;
 }
 return {
  receive(r,now,hooks={}){
   if(typeof r.id!=='string'||typeof r.payload!=='string'||!Number.isFinite(r.deadline)||r.signature!==token(r))return {status:'INVALID'};
   const result=transaction(db,()=>{
    const t=effectiveTime(typeof now==='function'?now():now);
    hooks.locked?.();
    if(group!=='A'){
     const prior=db.prepare('SELECT * FROM dedup WHERE id=?').get(r.id);
     if(prior){
      if(prior.hash!==digest(r.payload)||prior.deadline!==r.deadline)return {status:'CONFLICT'};
      return {status:'COMMITTED',effect_id:prior.effect_id,replayed:true};
     }
    }
    if(group==='C'&&t>=r.deadline)return {status:'EXPIRED'};
    const effect=db.prepare('INSERT INTO effects(id,payload,at) VALUES(?,?,?)').run(r.id,r.payload,t);
    if(group!=='A')db.prepare('INSERT INTO dedup VALUES(?,?,?,?,?)').run(r.id,digest(r.payload),r.deadline,group==='C'?Math.max(t+ttl,r.deadline):t+ttl,Number(effect.lastInsertRowid));
    hooks.beforeCommit?.();
    return {status:'COMMITTED',effect_id:Number(effect.lastInsertRowid),replayed:false};
   });
   hooks.afterCommit?.();return result;
  },
  cleanup(now){return transaction(db,()=>{
   const t=effectiveTime(typeof now==='function'?now():now);
   return Number(db.prepare('DELETE FROM dedup WHERE retain_until<=?').run(t).changes);
  });},
  query(id){const row=db.prepare('SELECT seq FROM effects WHERE id=? ORDER BY seq LIMIT 1').get(id);return row?{status:'COMMITTED',effect_id:row.seq}:{status:'UNKNOWN'};},
  effects(){return db.prepare('SELECT * FROM effects ORDER BY seq').all();},
  stats(){return {dedup:db.prepare('SELECT COUNT(*) n FROM dedup').get().n,effects:db.prepare('SELECT COUNT(*) n FROM effects').get().n};},
  close(){db.close();}
 };
}
export function openSender(path){
 const db=database(path);
 db.exec(`CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY,payload TEXT,deadline REAL);
 CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY,payload TEXT,deadline REAL,signature TEXT,state TEXT,attempts INTEGER,confirmed_at REAL);
 CREATE TRIGGER IF NOT EXISTS immutable_request BEFORE UPDATE OF id,payload,deadline,signature ON outbox BEGIN SELECT RAISE(ABORT,'immutable request'); END;`);
 const get=id=>db.prepare('SELECT * FROM outbox WHERE id=?').get(id);
 return {
  enqueue(r,hooks={}){return transaction(db,()=>{
   const old=get(r.id);
   if(old){if(old.payload!==r.payload||old.deadline!==r.deadline||old.signature!==r.signature)throw Error('identity conflict');return old;}
   db.prepare('INSERT INTO alerts VALUES(?,?,?)').run(r.id,r.payload,r.deadline);hooks.afterAlert?.();
   db.prepare('INSERT INTO outbox VALUES(?,?,?,?,?,0,NULL)').run(r.id,r.payload,r.deadline,r.signature,'PENDING');return get(r.id);
  });},
  get,
  begin(id,now,group){return transaction(db,()=>{
   const row=get(id);if(!row)throw Error('missing task');
   if(['CONFIRMED','REJECTED','EXPIRED_UNKNOWN'].includes(row.state))return null;
   if(group==='C'&&now>=row.deadline){db.prepare("UPDATE outbox SET state='EXPIRED_UNKNOWN' WHERE id=?").run(id);return null;}
   db.prepare("UPDATE outbox SET state='IN_FLIGHT',attempts=attempts+1 WHERE id=?").run(id);return get(id);
  });},
  finish(id,response,now){
   if(response.status==='COMMITTED')db.prepare("UPDATE outbox SET state='CONFIRMED',confirmed_at=? WHERE id=?").run(now,id);
   else if(response.status==='EXPIRED')db.prepare("UPDATE outbox SET state='EXPIRED_UNKNOWN' WHERE id=? AND state!='CONFIRMED'").run(id);
   else if(['CONFLICT','INVALID'].includes(response.status))db.prepare("UPDATE outbox SET state='REJECTED' WHERE id=? AND state!='CONFIRMED'").run(id);
  },
  rows(){return db.prepare('SELECT * FROM outbox ORDER BY id').all();},
  close(){db.close();}
 };
}
