// Separate recovery time from in-flight arrival time; no probabilistic claim.
import {mkdirSync,existsSync,writeFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import assert from 'node:assert/strict';
import {openReceiver,openSender,sign} from './core.mjs';
const out=resolve(process.argv[2]||'runs/supplement');
mkdirSync(out,{recursive:true});
if(existsSync(join(out,'results.json')))throw Error('Refusing overwrite');
const rows=[];
for(const group of ['A','B','C'])for(const recovery of [5,120])for(const arrival of [20,130])for(const ttl of [10,150])for(const initiallyApplied of [false,true]){
 const label=`${group}-recovery${recovery}-arrival${arrival}-ttl${ttl}-initial${initiallyApplied}`;
 const dir=join(out,label);mkdirSync(dir);
 const s=openSender(join(dir,'sender.db')),r=openReceiver(join(dir,'receiver.db'),group,{ttl});
 const req=sign({id:label,payload:'B:61',deadline:100}),trace=[];
 s.enqueue(req);s.begin(req.id,0,group);
 if(initiallyApplied)trace.push({t:0,action:'first response deliberately lost',result:r.receive(req,0)});
 else trace.push({t:0,action:'first request unavailable'});
 const envelope=s.begin(req.id,1,group);assert.ok(envelope);trace.push({t:1,action:'persisted in-flight send'});
 const schedule=[{t:recovery,action:'recover'},{t:arrival,action:'arrival'},{t:101,action:'expiry scan'}].sort((a,b)=>a.t-b.t);
 for(const event of schedule){
  r.cleanup(event.t);let result=null;
  if(event.action==='arrival'){result=r.receive(envelope,event.t);s.finish(req.id,result,event.t);}
  else if(event.action==='recover'){const retry=s.begin(req.id,event.t,group);if(retry){result=r.receive(retry,event.t);s.finish(req.id,result,event.t);}}
  else if(group==='C')s.begin(req.id,event.t,group);
  trace.push({...event,result,state:s.get(req.id).state});
 }
 const beforeQuery=s.get(req.id).state;
 if(beforeQuery==='EXPIRED_UNKNOWN'){const q=r.query(req.id);s.finish(req.id,q,150);trace.push({t:150,action:'audit query',result:q});}
 const effects=r.effects(),sender=s.get(req.id);
 if(group==='C')assert.ok(effects.length<=1);
 const expected=group==='C'&&!initiallyApplied&&recovery>=100&&arrival>=100?0:1;
 if(group==='C')assert.equal(effects.length,expected);
 rows.push({label,group,recovery,arrival,ttl,initiallyApplied,effects:effects.length,extra:Math.max(effects.length-1,0),missing:effects.length===0,attempts:sender.attempts,beforeQuery,afterQuery:sender.state,trace});
 r.close();s.close();
}
const boundaries=[];
for(const t of [99,100,101]){
 const r=openReceiver(join(out,`boundary-${t}.db`),'C');
 const response=r.receive(sign({id:'boundary',payload:'B:61',deadline:100}),t);
 assert.equal(response.status,t<100?'COMMITTED':'EXPIRED');
 boundaries.push({t,response,effects:r.effects().length});r.close();
}
writeFileSync(join(out,'results.json'),JSON.stringify({rows,boundaries},null,2));
const keys=['label','group','recovery','arrival','ttl','initiallyApplied','effects','extra','missing','attempts','beforeQuery','afterQuery'];
writeFileSync(join(out,'results.csv'),keys.join(',')+'\n'+rows.map(r=>keys.map(k=>r[k]).join(',')).join('\n')+'\n');
console.log(JSON.stringify({scenarios:rows.length,boundaries:boundaries.length,totals:['A','B','C'].map(group=>({group,n:rows.filter(r=>r.group===group).length,extra:rows.filter(r=>r.group===group).reduce((s,r)=>s+r.extra,0),missing:rows.filter(r=>r.group===group&&r.missing).length}))},null,2));
