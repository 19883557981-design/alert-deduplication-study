import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {openReceiver,openSender,sign} from './core.mjs';
const request=sign({id:'B:window:rule1',payload:'61 ships',deadline:100});
test('C rejects a request arriving after its immutable deadline even without dedup history',()=>{
 const r=openReceiver(join(mkdtempSync(join(tmpdir(),'alert-test-')),'r.db'),'C');
 try {assert.equal(r.receive(request,101).status,'EXPIRED');} finally {r.close();}
});
for(const group of ['A','B','C']) test(`${group}: ack loss and cross-retention retry`,()=>{
 const r=openReceiver(join(mkdtempSync(join(tmpdir(),'alert-test-')),'r.db'),group,{ttl:10});
 try {
  assert.equal(r.receive(request,0).status,'COMMITTED');
  r.receive(request,1);
  assert.equal(r.effects().length,group==='A'?2:1);
  r.cleanup(101); r.receive(request,102);
  assert.equal(r.effects().length,group==='A'?3:group==='B'?2:1);
 }finally{r.close();}
});
test('C protects still-valid requests beyond naive TTL and rejects altered requests',()=>{
 const r=openReceiver(join(mkdtempSync(join(tmpdir(),'alert-test-')),'r.db'),'C',{ttl:10});
 try{
  r.receive(request,0); r.cleanup(20); r.receive(request,21);
  assert.equal(r.effects().length,1);
  assert.equal(r.receive({...request,deadline:200},22).status,'INVALID');
  assert.equal(r.receive(sign({...request,payload:'different'}),23).status,'CONFLICT');
  r.cleanup(101); assert.equal(r.receive(request,1).status,'EXPIRED');
 }finally{r.close();}
});
test('sender persists tasks, recovers in-flight and never extends identity or deadline',()=>{
 const path=join(mkdtempSync(join(tmpdir(),'alert-test-')),'s.db');
 let s=openSender(path); s.enqueue(request); s.begin(request.id,0,'C'); s.close();
 s=openSender(path);
 try{
  assert.equal(s.get(request.id).state,'IN_FLIGHT');
  assert.equal(s.begin(request.id,1,'C').attempts,2);
  assert.throws(()=>s.enqueue(sign({...request,deadline:200})));
  assert.equal(s.begin(request.id,101,'C'),null);
  assert.equal(s.get(request.id).state,'EXPIRED_UNKNOWN');
  s.finish(request.id,{status:'COMMITTED'},102);
  assert.equal(s.get(request.id).state,'CONFIRMED');
 }finally{s.close();}
});
