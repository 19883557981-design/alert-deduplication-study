import {mkdirSync,writeFileSync,readFileSync,existsSync,statSync,readdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {openReceiver,openSender,sign} from './core.mjs';
const base=fileURLToPath(new URL('.',import.meta.url));
const out=resolve(process.argv[2]||join(base,'runs',new Date().toISOString().replace(/[:.]/g,'-')));
mkdirSync(out,{recursive:true});
if(existsSync(join(out,'manifest.json')))throw Error('Refusing to overwrite existing run');
writeFileSync(join(out,'manifest.json'),JSON.stringify({node:process.version,platform:process.platform,date:new Date().toISOString(),time:'injected logical seconds; process barriers use wall time',seeds:[17,29,43],tasksPerConfig:40},null,2));
const events=[],det=[];
let serial=0;
function child(args){
 const id=serial++,marker=join(out,`barrier-${id}.json`),release=join(out,`release-${id}`);
 const c=spawn(process.execPath,[join(base,'worker.mjs'),JSON.stringify({...args,marker,release})],{stdio:['ignore','pipe','pipe'],windowsHide:true});
 let stdout='',stderr='';c.stdout.on('data',b=>stdout+=b);c.stderr.on('data',b=>stderr+=b);
 const done=new Promise((res,rej)=>{c.on('error',rej);c.on('close',(code,signal)=>res({code,signal,stdout,stderr,pid:c.pid}));});
 return {c,marker,release,done};
}
async function waitFile(p){const start=Date.now();while(!existsSync(p)){if(Date.now()-start>12000)throw Error(`Missing barrier ${p}`);await new Promise(r=>setTimeout(r,10));}}
async function finish(p,killed=false){const v=await p.done;events.push(v);if(!killed)assert.equal(v.code,0,v.stderr);return v;}
async function killAt(p){
 await waitFile(p.marker);assert.equal(p.c.kill('SIGKILL'),true,'OS kill request failed');
 const result=await finish(p,true);assert.ok(result.signal==='SIGKILL'||(result.code!==null&&result.code!==0),'expected forced process termination');
 assert.equal(result.stderr,'','barrier must not time out or throw');return result;
}
function fresh(label,group){const dir=join(out,label+'-'+group);mkdirSync(dir);const db=join(dir,'receiver.db');openReceiver(db,group).close();return {dir,db,group,ttl:10,request:sign({id:label,payload:'sea B: 61 ships',deadline:100})};}
function inspect(f){const r=openReceiver(f.db,f.group);const result={effects:r.effects(),storage:r.stats()};r.close();return result;}
function record(name,f,extra={}){const row={name,group:f.group,...inspect(f),...extra};det.push(row);return row;}
function rec(f,now,extra={}){return child({role:'receiver',db:f.db,group:f.group,ttl:f.ttl,request:f.request,now,...extra});}

// F01/F02: actual receiver termination before/after durable commit.
for(const group of ['A','B','C'])for(const [name,stage,want] of [['F01','beforeCommit',1],['F02','afterCommit',group==='A'?2:1]]){
 const f=fresh(name,group);await killAt(rec(f,0,{pause:stage}));
 const before=inspect(f).effects.length;assert.equal(before,name==='F01'?0:1);
 await finish(rec(f,1));const row=record(name,f,{afterCrash:before});assert.equal(row.effects.length,want);
}
// F03: separately running sender gets a real receiver response, then is killed
// before persisting it. Restart reads its durable IN_FLIGHT record.
for(const group of ['A','B','C']){
 const f=fresh('F03',group),sdb=join(f.dir,'sender.db');let s=openSender(sdb);s.enqueue(f.request);s.close();
 const outgoing=join(f.dir,'outgoing.json'),incoming=join(f.dir,'incoming.json');
 const p=child({role:'sender',action:'send',db:sdb,group,request:f.request,now:0,outgoing,incoming,pause:'beforeSave'});
 await waitFile(outgoing);const response=await finish(rec(f,0));writeFileSync(incoming,response.stdout);await killAt(p);
 s=openSender(sdb);assert.equal(s.get(f.request.id).state,'IN_FLIGHT');const retry=s.begin(f.request.id,1,group);assert.equal(retry.attempts,2);
 const retryResponse=await finish(rec(f,1));s.finish(f.request.id,JSON.parse(retryResponse.stdout),1);
 const state=s.get(f.request.id);s.close();assert.equal(state.state,'CONFIRMED');assert.equal(record('F03',f,{sender:state}).effects.length,group==='A'?2:1);
}
// F00: kill between business creation and outbox write; both must roll back.
{
 const f=fresh('F00','C'),sdb=join(f.dir,'sender.db');openSender(sdb).close();
 await killAt(child({role:'sender',action:'enqueue',db:sdb,request:f.request,pause:'afterAlert'}));
 const db=new DatabaseSync(sdb);assert.equal(db.prepare('SELECT count(*) n FROM alerts').get().n,0);assert.equal(db.prepare('SELECT count(*) n FROM outbox').get().n,0);db.close();
 det.push({name:'F00',group:'C',alerts:0,outbox:0});
}
// F04: multiple real processes contend for one SQLite writer lock.
for(const group of ['A','B','C']){
 const f=fresh('F04',group);await Promise.all(Array.from({length:6},()=>finish(rec(f,0))));
 assert.equal(record('F04',f).effects.length,group==='A'?6:1);
}
// F05: request sent at 99 is delivered at 111, after cleanup. Transport retains
// original immutable envelope; receiver cannot rely on sender cancellation.
for(const group of ['A','B','C']){
 const f=fresh('F05',group);const r=openReceiver(f.db,group);r.receive(f.request,0);r.cleanup(110);
 const response=r.receive(f.request,111);r.close();
 assert.equal(record('F05',f,{sentAt:99,arrivedAt:111,response}).effects.length,group==='A'||group==='B'?2:1);
 if(group==='C')assert.equal(response.status,'EXPIRED');
}
// F06: late first delivery illustrates deadline's cost, not a silent success.
for(const group of ['A','B','C']){
 const f=fresh('F06',group);const r=openReceiver(f.db,group);const response=r.receive(f.request,111);r.close();
 assert.equal(record('F06',f,{response}).effects.length,group==='C'?0:1);
}
// F07: same signed identity with conflicting payload; unsigned deadline change.
{
 const f=fresh('F07','C'),r=openReceiver(f.db,'C');r.receive(f.request,0);
 const conflict=r.receive(sign({...f.request,payload:'62 ships'}),1);
 const invalid=r.receive({...f.request,deadline:200},2);
 assert.equal(conflict.status,'CONFLICT');assert.equal(invalid.status,'INVALID');r.close();record('F07',f,{conflict,invalid});
}
// F08: cleanup and duplicate wait behind a transaction paused while holding
// its write lock. Either order after release is safe for C.
{
 const f=fresh('F08','C');const p=rec(f,99,{pause:'beforeCommit'});await waitFile(p.marker);
 const cleanup=rec(f,101,{action:'cleanup'}),duplicate=rec(f,102);
 await new Promise(r=>setTimeout(r,100));writeFileSync(p.release,'release');
 await Promise.all([finish(p),finish(cleanup),finish(duplicate)]);
 const check=rec(f,103);await finish(check);assert.equal(record('F08',f).effects.length,1);
}
// F09: high-water time survives cleanup AND receiver restart. Availability
// after a forward clock jump is separately demonstrated by an unexecuted ID.
{
 const f=fresh('F09','C');let r=openReceiver(f.db,'C');r.receive(f.request,0);r.cleanup(110);r.close();
 r=openReceiver(f.db,'C');const response=r.receive(f.request,1);const freshResponse=r.receive(sign({...f.request,id:'new-after-clock-jump'}),2);r.close();
 assert.equal(response.status,'EXPIRED');assert.equal(freshResponse.status,'EXPIRED');record('F09',f,{response,freshResponse});
}
writeFileSync(join(out,'deterministic.json'),JSON.stringify(det,null,2));
writeFileSync(join(out,'process-events.json'),JSON.stringify(events,null,2));
console.log(`Deterministic cases: ${det.length} passed; starting paired batches`);

function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296;};}
const batches=[],raw=[];
for(const seed of [17,29,43])for(const loss of [0.25,0.75])for(const delay of [5,120])for(const ttl of [10,150]){
 const random=rng(seed);const workload=Array.from({length:40},(_,i)=>({i,ackLost:random()<loss,firstUnavailable:random()<0.2,jitter:random()}));
 for(const group of ['A','B','C']){
  const label=`batch-${seed}-${loss}-${delay}-${ttl}-${group}`,dir=join(out,label);mkdirSync(dir);
  const r=openReceiver(join(dir,'receiver.db'),group,{ttl}),s=openSender(join(dir,'sender.db'));
  let peakDedup=0;
  for(const w of workload){
   // Separate epochs maintain global logical time; durations remain comparable.
   const t=w.i*1000,request=sign({id:`task-${w.i}`,payload:'B:61',deadline:t+100});
   s.enqueue(request);s.begin(request.id,t,group);
   let first=null,retry=null,query=null;
   if(!w.firstUnavailable){first=r.receive(request,t);if(!w.ackLost)s.finish(request.id,first,t);}
   // Persist the actual send before retaining its envelope in the transport.
   const inTransit=(w.ackLost||w.firstUnavailable)&&delay===120?s.begin(request.id,t+1,group):null;
   const retryAt=t+delay+w.jitter;
   peakDedup=Math.max(peakDedup,r.stats().dedup);
   r.cleanup(retryAt);
   const pending=s.begin(request.id,retryAt,group);
   if(pending){retry=r.receive(request,retryAt);s.finish(request.id,retry,retryAt);}
   // One extra in-flight request was emitted at t+1 while result was unknown.
   // It can arrive beyond the deadline even though C stopped creating retries.
   let delayed=null;
   if(inTransit)delayed=r.receive(inTransit,retryAt+1);
   const before=s.get(request.id);
   if(before.state==='EXPIRED_UNKNOWN'){query=r.query(request.id);s.finish(request.id,query,retryAt+2);}
   const after=s.get(request.id),effects=r.effects().filter(e=>e.id===request.id);
   raw.push({label,seed,loss,delay,ttl,group,...w,id:request.id,deadline:request.deadline,first,retry,delayed,query,inTransitSentAt:inTransit?t+1:null,inTransitArrivalAt:inTransit?retryAt+1:null,before:before.state,after:after.state,attempts:after.attempts,effects:effects.length,firstEffectDelay:effects.length?effects[0].at-t:null,confirmedDelay:after.confirmed_at===null?null:after.confirmed_at-t});
  }
  const rows=raw.filter(x=>x.label===label),storage=r.stats();
  const summary={label,seed,loss,delay,ttl,group,n:rows.length,duplicateEffects:rows.reduce((a,x)=>a+Math.max(x.effects-1,0),0),missing:rows.filter(x=>x.effects===0).length,unknownBeforeQuery:rows.filter(x=>x.before!=='CONFIRMED').length,unknownAfterQuery:rows.filter(x=>x.after!=='CONFIRMED').length,appliedUnknownBeforeQuery:rows.filter(x=>x.before!=='CONFIRMED'&&x.effects>0).length,duplicateRequests:rows.reduce((a,x)=>a+x.attempts-1,0),peakDedup,storage};
  if(group==='C')assert.equal(summary.duplicateEffects,0);
  r.close();s.close();summary.databaseBytes=readdirSync(dir).filter(n=>n.endsWith('.db')).reduce((a,n)=>a+statSync(join(dir,n)).size,0);
  batches.push(summary);
 }
}
writeFileSync(join(out,'raw.jsonl'),raw.map(x=>JSON.stringify(x)).join('\n')+'\n');
writeFileSync(join(out,'batches.json'),JSON.stringify(batches,null,2));
const keys=['label','seed','loss','delay','ttl','group','n','duplicateEffects','missing','unknownBeforeQuery','unknownAfterQuery','appliedUnknownBeforeQuery','duplicateRequests','peakDedup','databaseBytes'];
writeFileSync(join(out,'batches.csv'),keys.join(',')+'\n'+batches.map(b=>keys.map(k=>b[k]).join(',')).join('\n')+'\n');
console.log(JSON.stringify({out,deterministic:det.length,batches:batches.length,tasks:raw.length,totals:['A','B','C'].map(group=>({group,...Object.fromEntries(['n','duplicateEffects','missing','unknownAfterQuery','duplicateRequests'].map(k=>[k,batches.filter(b=>b.group===group).reduce((a,b)=>a+b[k],0)]))}))},null,2));
