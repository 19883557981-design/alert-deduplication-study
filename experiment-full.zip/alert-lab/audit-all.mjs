import {readFileSync,writeFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {join} from 'node:path';
const check=spawnSync(process.execPath,['verify.mjs','runs/verified'],{encoding:'utf8'});
assert.equal(check.status,0,check.stderr);console.log(check.stdout.trim());
const supplement=JSON.parse(readFileSync('runs/supplement/results.json','utf8'));
for(const x of supplement.rows){
 const r=new DatabaseSync(join('runs/supplement',x.label,'receiver.db'),{readOnly:true});
 const s=new DatabaseSync(join('runs/supplement',x.label,'sender.db'),{readOnly:true});
 const n=r.prepare('SELECT count(*) n FROM effects').get().n;
 const state=s.prepare('SELECT state,attempts FROM outbox').get();
 assert.equal(n,x.effects);assert.equal(Math.max(n-1,0),x.extra);assert.equal(n===0,x.missing);
 assert.equal(state.state,x.afterQuery);assert.equal(state.attempts,x.attempts);r.close();s.close();
}
for(const x of supplement.boundaries){const db=new DatabaseSync(`runs/supplement/boundary-${x.t}.db`,{readOnly:true});assert.equal(db.prepare('SELECT count(*) n FROM effects').get().n,x.effects);db.close();}
const storage=JSON.parse(readFileSync('runs/storage/storage.json','utf8'));
for(const x of storage){const db=new DatabaseSync(`runs/storage/${x.group}-${x.ttl}.db`,{readOnly:true});assert.equal(db.prepare('SELECT count(*) n FROM effects').get().n,200);assert.equal(db.prepare('SELECT count(*) n FROM dedup').get().n,0);db.close();}
const raw=readFileSync('runs/verified/raw.jsonl','utf8').trim().split('\n').map(JSON.parse);
const summary=[];
for(const group of ['A','B','C']){
 const rows=raw.filter(r=>r.group===group);
 const quantile=(vals,p)=>{const s=vals.filter(v=>v!==null).sort((a,b)=>a-b);return {n:s.length,value:s.length?s[Math.ceil(p*s.length)-1]:null};};
 summary.push({group,n:rows.length,extra:rows.reduce((s,r)=>s+Math.max(r.effects-1,0),0),missing:rows.filter(r=>r.effects===0).length,firstEffectP95:quantile(rows.map(r=>r.firstEffectDelay),.95),confirmationP95:quantile(rows.map(r=>r.confirmedDelay),.95)});
}
writeFileSync('runs/verified/analysis-summary.json',JSON.stringify(summary,null,2));
console.log('Supplement: 48 SQLite pairs + 3 deadline databases audited; storage: 4 databases audited.');
console.log(JSON.stringify(summary,null,2));
